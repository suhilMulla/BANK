package org.slk.controller;

import org.springframework.web.bind.annotation.RestController;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.slk.dao.*;
import org.slk.model.*;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AdminController {
	@Autowired
	private AdminDao adminDao;

	/*@GetMapping("/Admin")
	public List getall() throws Exception {
		System.out.println("the functiuon inside controller");
		return employeeDAO.getallManagers();
	}*/
	
	@GetMapping("/{username}/{password}")
	public ResponseEntity login(@PathVariable("admin_username") String username ,@PathVariable("admin_password") String password) throws Exception {
		boolean ad = adminDao.login(username,password);
		System.out.println(username+" "+password);
		return new ResponseEntity(ad, HttpStatus.OK);

	}


	
	@GetMapping("/Admin/{admin_id}")
	public ResponseEntity getbyid(@PathVariable String admin_id) {
		// System.out.println("****");
		Admin ad = adminDao.getbyid(admin_id);
		adminDao.getbyid(admin_id);
		return new ResponseEntity(ad, HttpStatus.OK);
	}

	@PutMapping("/put/Admin/{admin_id}")
	public ResponseEntity update(@PathVariable String admin_id,@RequestBody Admin ad) {
		adminDao.update(admin_id, ad);
		return new ResponseEntity(ad, HttpStatus.OK);
	}

}


