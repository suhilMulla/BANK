package org.slk.dao;

import org.springframework.web.bind.annotation.RestController;

@RestController
public interface TransactionDao {
	public int transfer(String un,String pass,int amt,int acc_no);
	public void viewbalance(String un,String pass);
	public void viewAlltransactions();
	
}

