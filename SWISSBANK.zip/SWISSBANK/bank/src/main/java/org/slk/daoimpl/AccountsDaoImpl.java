package org.slk.daoimpl;

import org.slk.dao.AccountsDao;

public class AccountsDaoImpl implements AccountsDao{

}
