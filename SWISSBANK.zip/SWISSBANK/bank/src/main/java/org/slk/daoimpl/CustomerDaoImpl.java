package org.slk.daoimpl;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slk.dao.CustomerDao;
import org.slk.model.Customer;
import org.slk.util.DButil;

public class CustomerDaoImpl implements CustomerDao {
	
	Connection connection = DButil.getConnection();

	public CustomerDaoImpl() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}
	
	
	
	public List<Customer> getAllCustomers() throws Exception
	{
		
		List<Customer> customer = new ArrayList<Customer>();
		System.out.println("hfcgf");
		try {

			PreparedStatement stmt = connection.prepareStatement("select * from customer");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
                 Customer cst=new Customer();
             	cst.setCustomer_id(rs.getString(1));
             	System.out.println(rs.getString(1));
             	/*cst.setName(rs.getString(2));
             	cst.setDob(rs.getString(3));
             	cst.setContact(rs.getLong(4));
             	cst.setAddress(rs.getString(5));
             	cst.setUsername(rs.getString(6));
             	cst.setPassword(rs.getString(7));
             	cst.setAadhar_card(rs.getLong(8));
             	cst.setPan_card(rs.getString(9));
             	cst.setBranch_id(rs.getString(10));*/
             	
             	cst.setCustomer_ac_no(rs.getLong(2));
             	cst.setCustomer_name(rs.getString(3));
             	cst.setCustomer_dob(rs.getDate(4));
             	cst.setCustomer_email(rs.getString(5));
             	cst.setCustomer_phone(rs.getLong(6));
             	cst.setCustomer_aadhar(rs.getLong(7));
                cst.setCustomer_pan(rs.getString(8));
                cst.setCustomer_username(rs.getString(9));
                cst.setCustomer_password(rs.getString(10));
                cst.setCustomer_loan(rs.getString(11));
                cst.setCustomer_branch_ifsc(rs.getString(12));
                cst.setCustomer_ac_id(rs.getString(13));
               
				customer.add(cst);
				System.out.println(customer);
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
		
	}
	
	
	
	 public void updateCustomer(Customer customer)
	 {
		 
		 Statement stmt ;
			
			try {
				String query="select max(customer_id) from customer";
				stmt=connection.createStatement();
				ResultSet rs=stmt.executeQuery(query);
				rs.next();
				Long ab=rs.getLong(1);
				Long temp_id = ++ab;
				//String sql ="Insert into customer values(?,?,?,?,?,?,?,?,?,?)"; 
				PreparedStatement pst = connection.prepareStatement("Insert into customer values(?,?,?,?,?,?,?,?,?,?)");
	            pst.setLong(1,temp_id);
	            pst.setLong(2, customer.getCustomer_ac_no());
				pst.setString(3,customer.getCustomer_name());
				pst.setDate(4, (Date) customer.getCustomer_dob());
				pst.setString(5,customer.getCustomer_email());
				pst.setLong(6,customer.getCustomer_phone());
				pst.setLong(7, customer.getCustomer_aadhar());
				pst.setString(8, customer.getCustomer_pan());
				pst.setString(9,customer.getCustomer_username());
				pst.setString(10, customer.getCustomer_password());
				pst.setString(11, customer.getCustomer_loan());
				pst.setString(12, customer.getCustomer_branch_ifsc());
				pst.setString(13, customer.getCustomer_ac_id());
				
				System.out.println("Customer Updated");

				int res = pst.executeUpdate();
				
	               
				if (res > 0) {
					System.out.println("Customer Updated");

				}
		

			} catch (SQLException e) {
				e.printStackTrace();
			}
			
	 }

}
