package org.slk.daoimpl;

import org.slk.dao.LoanDao;
import org.slk.model.Loan;
import org.slk.util.DButil;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
public class LoanDaoImpl implements LoanDao {
	
	Connection connection = null;
	private static List<Loan> loans;
	
	{
		connection = DButil.getConnection();
		System.out.println(connection);
	}

	@Override
	public Loan addLoan(Loan loan) {
		// TODO Auto-generated method stub
		String select_query = "Select max(loan_id) from loan";
		Statement select_stmt;
		int i=0;
		try {
			select_stmt = connection.createStatement();
			ResultSet select_rs = select_stmt.executeQuery(select_query);

			select_rs.next();
			String loanid = "LO0";
			String loan_Id = select_rs.getString(1);
			int temp_id = Integer.parseInt(loan_Id.substring(2));
			int temp_loanId = ++temp_id;
			String id = loanid+temp_loanId;
			/*employee.setEmpId(temp_empId);
			employee.setName("Soumya");
			employee.setDob("1997-07-25");
			employee.setContact(876260339);
			employee.setUsername("sou");
			employee.setPwd("sou23");
			employee.setRole(role);*/
			PreparedStatement pst = connection.prepareStatement("Insert into Loan values(?,?,?,?)");
			
			pst.setString(1,id);
			pst.setString(2,loan.getLoan_type());
			pst.setFloat(3,loan.getLoan_roi());
			pst.setString(4,loan.getLoan_eligibility());
		
			
			i = pst.executeUpdate();
			System.out.println(i + " records inserted");
			//admins.add(employee);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return loan;
		
	
	}

	@Override
	public List<Loan> getAllLoans() {
		// TODO Auto-generated method stub
		String query = "Select * from loan";
		
		loans = new ArrayList<>();
		PreparedStatement st;
		try {
			
			st = connection.prepareStatement(query);
			
			ResultSet rs = st.executeQuery();
			
			while(rs.next()) {
				Loan loan = new Loan();
				String loan_id = rs.getString(1);
				String loan_type = rs.getString(2);
				float loan_roi = rs.getFloat(3);
				String loan_eligibility = rs.getString(4);
				
				loan.setLoan_id(loan_id);
				loan.setLoan_type(loan_type);
				loan.setLoan_roi(loan_roi);
				loan.setLoan_eligibility(loan_eligibility);
				loans.add(loan);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return loans;
		
	
	}

	@Override
	public Loan updateLoan(String loanId, Loan loan) {
		// TODO Auto-generated method stub
		try {
			String updSql = "UPDATE  loan set loan_type = ?, loan_roi = ?, loan_eligibility = ? WHERE loan_id = ?";
			PreparedStatement pst = connection.prepareStatement(updSql);
			
			pst.setString(1, loan.getLoan_type());
			pst.setFloat(2, loan.getLoan_roi());
			pst.setString(3, loan.getLoan_eligibility());
			pst.setString(4, loanId);
			
			
			
			int res  = pst.executeUpdate();
			
			if(res > 0)
			{
				System.out.println("Loan updated");
			}
			return loan;
		
		} catch (SQLException e)
		{
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}



	
		

	

}
