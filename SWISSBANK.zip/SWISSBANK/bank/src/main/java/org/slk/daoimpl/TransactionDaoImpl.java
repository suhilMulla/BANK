package org.slk.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.slk.dao.TransactionDao;
import org.slk.util.DButil;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TransactionDaoImpl implements TransactionDao {
	Connection connection = DButil.getConnection();

	public TransactionDaoImpl() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}
	
	@Override
	public int transfer(String un,String pass,int amt,int acc_no)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);		
		int bal=balance-amt;
		
		System.out.println("testttttttttttt");
		
		
		String query1="update customer set balance="+bal+" where customer_username='"+un+"'";
		Statement st1=(Statement) connection.createStatement();
		st1.executeUpdate(query1);
		
		String query3="select balance from customer where customer_ac_no="+acc_no+"";
		Statement st3=(Statement) connection.createStatement();
		ResultSet rs3=st.executeQuery(query3);
		rs3.next();
		int balance1=rs3.getInt(1);		
		int bal1=balance1+amt;
		System.out.println(bal1);

		String query2="update customer set balance="+bal1+" where customer_ac_no="+acc_no+"";
		Statement st2=(Statement) connection.createStatement();
		st.executeUpdate(query2);
		//System.out.println("Balance="+rs.getInt("balance"));
		System.out.println("Successfully tranferred");
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		return 1;
	}
	
	@Override
	public void viewbalance(String un,String pass)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=((java.sql.Statement) st).executeQuery(query);
		
		rs.next();
		System.out.println("Balance="+rs.getInt("balance"));
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	@Override
	public void viewAlltransactions()
	{
		try
		{
		
		String query="select * from transaction";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		
		while(rs.next())
		{
			
			System.out.print(rs.getInt("tid")+"  ");
			System.out.print(rs.getString("trans_date")+"  ");
			System.out.print(rs.getInt("credit")+"  ");
			System.out.print(rs.getInt("debit")+"  ");
			System.out.print(rs.getInt("acc_no")+"  ");
			System.out.println();
		}
		
		}
		
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}


}
