package org.slk.model;

import java.util.Date; 

public class Transaction {
private int tid;
private Date trans_date;
private long debit;
private long credit;
private long acc_no;
public Transaction(int tid, Date trans_date, long debit, long credit, long acc_no) {
	super();
	this.tid = tid;
	this.trans_date = trans_date;
	this.debit = debit;
	this.credit = credit;
	this.acc_no = acc_no;
}
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public Date getTrans_date() {
	return trans_date;
}
public void setTrans_date(Date trans_date) {
	this.trans_date = trans_date;
}
public long getDebit() {
	return debit;
}
public void setDebit(long debit) {
	this.debit = debit;
}
public long getCredit() {
	return credit;
}
public void setCredit(long credit) {
	this.credit = credit;
}
public long getAcc_no() {
	return acc_no;
}
public void setAcc_no(long acc_no) {
	this.acc_no = acc_no;
}

@Override
public String toString() {
	return "Transaction [tid=" + tid + ", trans_date=" + trans_date + ", debit=" + debit + ", credit=" + credit
			+ ", acc_no=" + acc_no + "]";
}



}

